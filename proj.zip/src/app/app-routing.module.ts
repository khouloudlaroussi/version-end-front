import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomePageComponent } from "./home-page/home-page.component";
import { SigninComponent } from "./pages/auth/signin/signin.component";
import { DashboardDefaultComponent } from "./pages/dashboard/dashboard-default/dashboard-default.component";
import { ListProjectComponent } from "./pages/mangerProject/list-project/list-project.component";
import { MangProjectComponent } from "./pages/mangerProject/mang-project/mang-project.component";
import { AddTacheComponent } from "./pages/mangertache/add-tache/add-tache.component";
import { AffecteTacheComponent } from "./pages/mangertache/affecte-tache/affecte-tache.component";
import { ListTacheComponent } from "./pages/mangertache/list-tache/list-tache.component";
import { UpdateDelateTacheComponent } from "./pages/mangertache/update-delate-tache/update-delate-tache.component";
import { SimplePageComponent } from "./pages/simple-page/simple-page.component";
// import { ProfileComponent } from "./pages/user/profile/profile.component";



const routes: Routes = [

  { path: "", component: SigninComponent },
  { path: "signin", component: SigninComponent },
  {
    path: "dashboard",
    component: HomePageComponent,
    children: [
      {
        path: '', component: DashboardDefaultComponent
      },
      // {
      //   path: "profil",
      //   component: ProfileComponent,
      // },
      // { path: "admin", component: AdminComponent },
      { path: "simple", component: SimplePageComponent },
      { path: "mang_proj", component: ListProjectComponent },
      { path: "mang_tach", component: ListTacheComponent },
      { path: "add_tache", component: AddTacheComponent },
      { path: "up_sup_tache", component: UpdateDelateTacheComponent },
      { path: "affecte-tache", component:AffecteTacheComponent },
     
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
