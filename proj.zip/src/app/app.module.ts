import { BrowserModule } from '@angular/platform-browser';
import {NgModule, NO_ERRORS_SCHEMA} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { AdminComponent } from './layout/admin/admin.component';
import { SharedModule } from './shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SigninComponent } from './pages/auth/signin/signin.component';
import { DashboardDefaultComponent } from './pages/dashboard/dashboard-default/dashboard-default.component';
import { SimplePageComponent } from './pages/simple-page/simple-page.component';
import { HomePageComponent } from './home-page/home-page.component';
import { PopupComponent } from './popup/popup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListProjectComponent } from './pages/mangerProject/list-project/list-project.component';
import { MangProjectComponent } from './pages/mangerProject/mang-project/mang-project.component';
import { ListTacheComponent } from './pages/mangertache/list-tache/list-tache.component';
import { MangTacheComponent } from './pages/mangertache/mang-tache/mang-tache.component';
import { AffecteTacheComponent } from './pages/mangertache/affecte-tache/affecte-tache.component';
import { AddTacheComponent } from './pages/mangertache/add-tache/add-tache.component';
import { UpdateDelateTacheComponent } from './pages/mangertache/update-delate-tache/update-delate-tache.component';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { EroureComponent } from './eroure/eroure.component';
import { DeleteConfiremComponent } from './pages/mangerProject/delete-confirem/delete-confirem.component';
// import { ListUserComponent } from './user/list-user/list-user.component';
// import { KhouloudComponent } from './user/list-user/khouloud/khouloud.component';
// import { MangUserComponent } from './user/list-user/delete-confirem/mang-user/mang-user.component';
// import { UserComponent } from './user/user.component';
// import { KhouComponent } from './user/khou/khou.component';
// import { ZComponent } from './page/z/z.component';
// import { PageComponent } from './khou/page/page.component';
// import { SdsdComponent } from './sdsd/sdsd.component';
// import { DeleteUserComponent } from './user/delete-user/delete-user.component'; // <-- import the module
@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    SigninComponent,
    DashboardDefaultComponent,
    SimplePageComponent,
    HomePageComponent,
    PopupComponent,
    ListProjectComponent,
    MangProjectComponent,
    ListTacheComponent,
    MangTacheComponent,
    AffecteTacheComponent,
    AddTacheComponent,
    UpdateDelateTacheComponent,
    EroureComponent,
    DeleteConfiremComponent,

  

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    BrowserAnimationsModule, // required animations module
    //HomePageComponent
    //BreadcrumbsComponent
    //SigninComponent,
    //BasicLoginComponent,
    //DashboardDefaultComponent
  ],
  entryComponents: [MangProjectComponent,EroureComponent,DeleteConfiremComponent],
  schemas: [ NO_ERRORS_SCHEMA ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
