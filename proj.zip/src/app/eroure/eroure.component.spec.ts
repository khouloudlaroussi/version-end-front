import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EroureComponent } from './eroure.component';

describe('EroureComponent', () => {
  let component: EroureComponent;
  let fixture: ComponentFixture<EroureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EroureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EroureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
