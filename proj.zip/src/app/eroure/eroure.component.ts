import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-eroure',
  templateUrl: './eroure.component.html',
  styleUrls: ['./eroure.component.scss']
})
export class EroureComponent implements OnInit {
  @Input() titre;
  @Input() msg;


  constructor(public activeModal: NgbActiveModal ) { }


  ngOnInit() {
  }

}
