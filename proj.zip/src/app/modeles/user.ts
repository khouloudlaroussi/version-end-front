export class User {
        id_user ?: string;
        type?: string;
        nom: string;
        prenom:string;
        tel: string;
        email: string;
        passwored : string;
        adress : string;
        statut?: string;
        constructor( nom: string, prenom:string, tel: string,
         email: string, passwored:string, adress : string,
        id_user ?: string,type?: string , statut?:string) {
          this.nom = nom;
          this.prenom = prenom;
          this. tel =  tel;
          this. email = email;
          this.passwored = passwored;
          this. adress =  adress;
          this. id_user = id_user;
          this.type = type;
          this.statut =statut;
}
}