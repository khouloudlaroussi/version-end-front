import { Component, NgModule, OnInit } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";



@Component({
  selector: "app-signin",
  templateUrl: "./signin.component.html",
  styleUrls: ["./signin.component.scss"],
})
export class SigninComponent implements OnInit {

  // Form Control
  loginForm = new FormGroup({
    email: new FormControl("", [
      Validators.required,
      Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
    ]),
    password: new FormControl(
      "",
      Validators.required && Validators.minLength(6)
    ),
  });

  constructor(  private route:Router) {}

  ngOnInit() {}

  // async onSignin(email: string, password: string) {
  //   console.log(email, password);

  //   this.authServ.getLogin(email, password).subscribe((data) => {
  //     let resp: any;
  //     resp = data;
  //     if (resp.erorer == false) {
  //       localStorage.setItem('myUser',JSON.stringify(resp.msg));
  //       //console.log('user email : ', JSON.parse(localStorage.getItem('myUser')).email);
  //       this.route.navigate(['/dashboard'])
  //     } else if (resp.erorer == true) {
  //       alert(resp.msg);
  //     }
  //   });
  // }
}
