import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProjectService } from '../../../service/project.service';

@Component({
  selector: 'app-delete-confirem',
  templateUrl: './delete-confirem.component.html',
  styleUrls: ['./delete-confirem.component.scss']
})
export class DeleteConfiremComponent implements OnInit {
  @Input() titre;
  @Input() msg;
  @Input() id;
  constructor(private router: Router,public activeModal: NgbActiveModal,private serviceProject:ProjectService) { }


  ngOnInit() {
  }
  confirem()
  {
   this.serviceProject.deleteProject(this.id).subscribe(data=>{
     let resp :any;
     resp=data;
     let donne:boolean;
     donne=resp.errorer;
     if(!donne){
      this.activeModal.dismiss();
      this.closeReload();
     }
   })
  }
  closeReload() {
    const currentRoute = this.router.url;

    this.activeModal.dismiss();
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]); // navigate to same route
    });
  }

}