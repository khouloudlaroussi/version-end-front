import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EroureComponent } from '../../../eroure/eroure.component';
import { Project } from '../../../modeles/project';
import { ProjectService } from '.././../../service/project.service';


@Component({
  selector: 'app-mang-project',
  templateUrl: './mang-project.component.html',
  styleUrls: ['./mang-project.component.scss']
})
export class MangProjectComponent implements OnInit {
@Input() addp;
  @Input() titre;
  @Input() id;
 


  model:any={};


  constructor(private router: Router,public activeModal: NgbActiveModal,private serviceproject:ProjectService,private modalService: NgbModal) { }

  ngOnInit() {
   if(!this.addp)
   {
     this.getoneproject();
   }
  }
  onSubmit(form:NgForm)
  {
    alert('ok')
    console.log(form);
  }
  closeReload() {
    const currentRoute = this.router.url;

    this.activeModal.dismiss();
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]); // navigate to same route
    });
  }
  add() {
    const proj = new  Project(this.model.nomp.toString(),this.model.date_fin.toString(),this.model.date_debut.toString(),this.model.descrption.toString(),"2");
   try {
        const { msg, erorer } =  this.serviceproject.addproject(proj) as any || [];
        if (erorer) {
        }
  
      } catch (error) {
       
      }
      this.closeReload();
    }




  getoneproject()
    {
      
this.serviceproject.getOneProject(this.id).subscribe(data=>{
  let resp:any;
  resp=data;
  let donne=resp.msg[0];
  this.model.nomp=donne.nom_project;
  this.model.date_debut=donne.date_debut_project;
  this.model.date_fin=donne.date_fin_project;
  this.model.descrption=donne.description_projet;

})

    }
    
    update()
    {
    const proj = new  Project(this.model.nomp.toString(),this.model.date_fin.toString(),this.model.date_debut.toString(),this.model.descrption.toString(),"2",this.id);
this.serviceproject.updateProject(proj).subscribe(data=>{
  let resp :any;
  resp=data;
  let errour:boolean;
  errour=resp.errorer;
  if(errour)
  {
    this.activeModal.dismiss();
    const modalRef = this.modalService.open(EroureComponent);
    modalRef.componentInstance.titre = 'Erour de Modification ';
    modalRef.componentInstance.msg = resp.msg;

  }else{
    this.closeReload();
  }

})

    }
}
