import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tache',
  templateUrl: './add-tache.component.html',
  styleUrls: ['./add-tache.component.scss']
})
export class AddTacheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
