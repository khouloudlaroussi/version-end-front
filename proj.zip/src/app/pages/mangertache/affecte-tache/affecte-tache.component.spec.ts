import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffecteTacheComponent } from './affecte-tache.component';

describe('AffecteTacheComponent', () => {
  let component: AffecteTacheComponent;
  let fixture: ComponentFixture<AffecteTacheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffecteTacheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffecteTacheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
