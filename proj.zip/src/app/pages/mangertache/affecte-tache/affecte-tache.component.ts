import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-affecte-tache',
  templateUrl: './affecte-tache.component.html',
  styleUrls: ['./affecte-tache.component.scss']
})
export class AffecteTacheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
