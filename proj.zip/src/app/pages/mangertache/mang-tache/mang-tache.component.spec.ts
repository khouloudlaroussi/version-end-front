import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MangTacheComponent } from './mang-tache.component';

describe('MangTacheComponent', () => {
  let component: MangTacheComponent;
  let fixture: ComponentFixture<MangTacheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MangTacheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MangTacheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
