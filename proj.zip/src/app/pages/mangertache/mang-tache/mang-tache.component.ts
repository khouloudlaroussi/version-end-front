import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mang-tache',
  templateUrl: './mang-tache.component.html',
  styleUrls: ['./mang-tache.component.scss']
})
export class MangTacheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
