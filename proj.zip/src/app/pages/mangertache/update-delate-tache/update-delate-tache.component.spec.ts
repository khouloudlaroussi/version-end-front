import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDelateTacheComponent } from './update-delate-tache.component';

describe('UpdateDelateTacheComponent', () => {
  let component: UpdateDelateTacheComponent;
  let fixture: ComponentFixture<UpdateDelateTacheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDelateTacheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDelateTacheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
