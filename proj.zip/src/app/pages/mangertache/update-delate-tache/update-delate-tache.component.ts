import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-delate-tache',
  templateUrl: './update-delate-tache.component.html',
  styleUrls: ['./update-delate-tache.component.scss']
})
export class UpdateDelateTacheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
