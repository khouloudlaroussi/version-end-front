import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Project } from '../modeles/project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private httpClient:HttpClient ) { }
  addproject(proj:Project)
  {
    let param1 = new HttpParams;
    param1=param1.set("nom_project",proj.nom_project.toString());
    param1=param1.set("date_fin_project",proj.date_fin_project.toString());
    param1=param1.set("date_debut_project",proj.date_debut_project.toString());
    param1=param1.set("description_projet",proj.description_projet.toString());
    param1=param1.set("id_admine",proj.id_admine.toString());

    return new Promise((resolve, reject) => {
      this.httpClient.post('http://127.0.0.1/project_pfe/Projet/insert_projet',param1)
      .forEach(data =>
        resolve(data)).
        catch((err)=>
        {reject(err);
        });
      });
  }

  getAllProject()
  {
    return this.httpClient.get("http://127.0.0.1/project_pfe/Projet/get_All_projet");
  }
  getOneProject(id:string)
  {
    let param1= new HttpParams;
    param1=param1.set('id',id.toString()) ;
    let req;
    req={
      params:param1
    }
    return this.httpClient.get("http://127.0.0.1/project_pfe/Projet/get_one_projet",req);
  }
  updateProject(proj:Project)
  {
    let param1 = new HttpParams;
    param1=param1.set("nom_project",proj.nom_project);
    param1=param1.set("date_fin_project",proj.date_fin_project);
    param1=param1.set("date_debut_project",proj.date_debut_project);
    param1=param1.set("description_projet",proj.description_projet);
    param1=param1.set("id_admine",proj.id_admine);
    param1=param1.set("id",proj.id_projet);
    return this.httpClient.post("http://127.0.0.1/project_pfe/Projet/update_projet",param1);
  }
  deleteProject(id:string)
  {
    let param1 = new HttpParams;
    param1=param1.set("id",id);
    return this.httpClient.post("http://127.0.0.1/project_pfe/Projet/delete_projet",param1);
  }

}
