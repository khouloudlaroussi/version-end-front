import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  // param1=param1.set("adress",user.adress.toString());
  // param1=param1.set("tel",user.tel.toString());
  // param1=param1.set("nom",user.nom.toString());
  // param1=param1.set("prenom",user.prenom.toString());
  // param1=param1.set("email",user.email.toString());
  // param1=param1.set("passwored",user.passwored.toString());
}
